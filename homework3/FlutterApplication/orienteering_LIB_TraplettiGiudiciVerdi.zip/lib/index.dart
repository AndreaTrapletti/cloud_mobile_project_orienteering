// Export pages
export 'home_page/home_page_widget.dart' show HomePageWidget;
export 'racelist/racelist_widget.dart' show RacelistWidget;
export 'newrace/newrace_widget.dart' show NewraceWidget;
export 'caricagara/caricagara_widget.dart' show CaricagaraWidget;
export 'classlist/classlist_widget.dart' show ClasslistWidget;
export 'result/result_widget.dart' show ResultWidget;
export 'start_list/start_list_widget.dart' show StartListWidget;
export 'organization_result/organization_result_widget.dart'
    show OrganizationResultWidget;
export 'result_byorg/result_byorg_widget.dart' show ResultByorgWidget;
export 'carica_grigliapartenza/carica_grigliapartenza_widget.dart'
    show CaricaGrigliapartenzaWidget;
