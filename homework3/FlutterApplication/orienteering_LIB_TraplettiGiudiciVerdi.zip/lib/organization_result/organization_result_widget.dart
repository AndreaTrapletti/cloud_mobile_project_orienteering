import '../backend/api_requests/api_calls.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../home_page/home_page_widget.dart';
import '../result/result_widget.dart';
import '../result_byorg/result_byorg_widget.dart';
import '../start_list/start_list_widget.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class OrganizationResultWidget extends StatefulWidget {
  const OrganizationResultWidget({
    Key key,
    this.raceid,
    this.categoria,
  }) : super(key: key);

  final String raceid;
  final String categoria;

  @override
  _OrganizationResultWidgetState createState() =>
      _OrganizationResultWidgetState();
}

class _OrganizationResultWidgetState extends State<OrganizationResultWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
          backgroundColor: Color(0xFFFC6423),
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30,
            borderWidth: 1,
            buttonSize: 80,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 50,
            ),
            onPressed: () async {
              await Navigator.push(
                context,
                PageTransition(
                  type: PageTransitionType.leftToRight,
                  duration: Duration(milliseconds: 300),
                  reverseDuration: Duration(milliseconds: 300),
                  child: StartListWidget(
                    raceid: widget.raceid,
                  ),
                ),
              );
            },
          ),
          flexibleSpace: Align(
            alignment: AlignmentDirectional(0.05, 0.4),
            child: InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomePageWidget(),
                  ),
                );
              },
              child: Text(
                'Organizzazioni',
                style: FlutterFlowTheme.of(context).title2.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 30,
                    ),
              ),
            ),
          ),
          actions: [
            Align(
              alignment: AlignmentDirectional(0, 2),
              child: InkWell(
                onTap: () async {
                  await Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: Duration(milliseconds: 300),
                      reverseDuration: Duration(milliseconds: 300),
                      child: ResultWidget(
                        raceid: widget.raceid,
                        categoria: widget.categoria,
                      ),
                    ),
                  );
                },
                child: Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 50,
                ),
              ),
            ),
          ],
          elevation: 2,
        ),
      ),
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print('FloatingActionButton pressed ...');
        },
        backgroundColor: Color(0xFFFC6423),
        elevation: 8,
        child: InkWell(
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => OrganizationResultWidget(
                  raceid: widget.raceid,
                  categoria: widget.categoria,
                ),
              ),
            );
          },
          child: Icon(
            Icons.update,
            color: Colors.white,
            size: 35,
          ),
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: FutureBuilder<ApiCallResponse>(
            future: OrganizationCall.call(
              id: widget.raceid,
              categoria: widget.categoria,
            ),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 50,
                    height: 50,
                    child: CircularProgressIndicator(
                      color: FlutterFlowTheme.of(context).primaryColor,
                    ),
                  ),
                );
              }
              final listViewOrganizationResponse = snapshot.data;
              return Builder(
                
                builder: (context) {
                  try{

                  
                  final listaatleti = getJsonField(
                        (listViewOrganizationResponse?.jsonBody ?? ''),
                        r'''$.Organizzazioni[*]''',
                      )?.toList() ??
                      [];
                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: listaatleti.length,
                    itemBuilder: (context, listaatletiIndex) {
                      final listaatletiItem = listaatleti[listaatletiIndex];
                      return Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Color(0xFFFCAA8E),
                        ),
                        child: InkWell(
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ResultByorgWidget(
                                  raceid: widget.raceid,
                                  categoria: widget.categoria,
                                  organizzazione: getJsonField(
                                    listaatletiItem,
                                    r'''$''',
                                  ).toString(),
                                ),
                              ),
                            );
                          },
                          child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(10, 0, 10, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                getJsonField(
                                  listaatletiItem,
                                  r'''$''',
                                ).toString(),
                                style: FlutterFlowTheme.of(context)
                                    .bodyText1
                                    .override(
                                      fontFamily: 'Poppins',
                                      fontSize: 23,
                                      
                                    ),
                                    
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [],
                              ),
                              Icon(
                                Icons.double_arrow_outlined,
                                color: Color(0xFF468D17),
                                size: 50,
                              ),
                            ],
                          ),
                        ),
                      ),
                      );
                    },
                  );
                } catch (e){

                  List<String> listaatleti = [];
                  listaatleti.add(getJsonField(
                        (listViewOrganizationResponse?.jsonBody ?? ''),
                        r'''$.Organizzazioni[*]''',
                      )?.toString() ??
                      []);
                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: listaatleti.length,
                    itemBuilder: (context, listaatletiIndex) {
                      final listaatletiItem = listaatleti[listaatletiIndex];
                      print(listaatleti[0]);
                      return Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Color(0xFFFCAA8E),
                        ),
                        child: InkWell(
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ResultByorgWidget(
                                  raceid: widget.raceid,
                                  categoria: widget.categoria,
                                  organizzazione: getJsonField(
                                    listaatletiItem,
                                    r'''$''',
                                  ).toString(),
                                ),
                              ),
                            );
                          },
                          child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(10, 0, 10, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                getJsonField(
                                  listaatletiItem,
                                  r'''$''',
                                ).toString(),
                                style: FlutterFlowTheme.of(context)
                                    .bodyText1
                                    .override(
                                      fontFamily: 'Poppins',
                                      fontSize: 23,
                                      
                                    ),
                                    
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [],
                              ),
                              Icon(
                                Icons.double_arrow_outlined,
                                color: Color(0xFF468D17),
                                size: 50,
                              ),
                            ],
                          ),
                        ),
                      ),
                      );
                    },
                  );
                }
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
