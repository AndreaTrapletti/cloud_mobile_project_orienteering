import '../../flutter_flow/flutter_flow_util.dart';

import 'api_manager.dart';
import 'dart:async';
import 'dart:io';
export 'api_manager.dart' show ApiCallResponse;
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'dart:convert';

class RegisterraceCall {
  static Future<ApiCallResponse> call({
    String email = '',
    String nomeGara = '',
    String data = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'Registerrace',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/register_race?race_name=${nomeGara}&race_date=${data}&email=${email}',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      bodyType: BodyType.NONE,
      returnBody: true,
    );
  }
}

class UploadxmlCall {
  static Future<String> call({
    String id = '',
    String token = '',
    String uri = '',
  }) async {
    var url = Uri.parse(
        "https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/uploadxml?race_id=$id");
    var request =  http.MultipartRequest("POST", url);
    
    String token2 = id + "-" + token;
   
    
    final headers = {"jwt_token": token2};
    
    final response = await http.post(url, headers:headers, body:uri);
    //504 è il caso in cui l'xml è molto lungo, quindi viene superato il time_out di apigateway.
    if(response.statusCode == 200 || response.statusCode == 504){
      print(response.statusCode);
      return "riuscito";
    }
    else{
      print(response.statusCode);
      return "non riuscito";
    }

    
  }
}

class ListRaceCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'list race',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/list_races',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic nome(dynamic response) => getJsonField(
        response,
        r'''$..race_name''',
      );
  static dynamic data(dynamic response) => getJsonField(
        response,
        r'''$..race_date''',
      );
  static dynamic id(dynamic response) => getJsonField(
        response,
        r'''$..race_id''',
      );
}

class ListclassCall {
  static Future<ApiCallResponse> call({
    String id = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'listclass',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/list_classes?id=${id}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class ResultCall {
  static Future<ApiCallResponse> call({
    String id = '',
    String classe = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'result',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/results?id=${id}&Categoria=${classe}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class UploadStartlistCall {
  static Future<String> call({
    String id = '',
    String token = '',
    String file = '',
  }) async {
     var url = Uri.parse(
        "https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/upload_start_list?race_id=$id");
    var request =  http.MultipartRequest("POST", url);
    
    String token2 = id + "-" + token;
    
    
    final headers = {"jwt_token": token2};
    

    final response = await http.post(url, headers:headers, body:file);
 
    if(response.statusCode == 200 || response.statusCode == 504){
      print(response.statusCode);
      return "riuscito";
    }
    else{
      print(response.statusCode);
      return "non riuscito";
    }

    
  }
}

class GetstartlistCall {
  static Future<ApiCallResponse> call({
    String id = '',
    String categoria = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'getstartlist',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/start_list?id=${id}&Categoria=${categoria}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class OrganizationCall {
  static Future<ApiCallResponse> call({
    String id = '',
    String categoria = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'organization',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/list_organisation?id=${id}&Categoria=${categoria}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class OrgresultCall {
  static Future<ApiCallResponse> call({
    String id = '',
    String categoria = '',
    String organisation = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'orgresult',
      apiUrl:
          'https://hn36l3ei1m.execute-api.us-east-1.amazonaws.com/fase_tgv/results?id=${id}&Categoria=${categoria}&organisation=${organisation}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}
