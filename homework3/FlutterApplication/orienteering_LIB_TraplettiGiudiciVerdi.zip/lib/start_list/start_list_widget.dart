import '../backend/api_requests/api_calls.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../home_page/home_page_widget.dart';
import '../organization_result/organization_result_widget.dart';
import '../result/result_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class StartListWidget extends StatefulWidget {
  const StartListWidget({
    Key key,
    this.raceid,
    this.categoria,
  }) : super(key: key);

  final String raceid;
  final String categoria;

  @override
  _StartListWidgetState createState() => _StartListWidgetState();
}

class _StartListWidgetState extends State<StartListWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
          backgroundColor: Color(0xFFFC6423),
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30,
            borderWidth: 1,
            buttonSize: 80,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 50,
            ),
            onPressed: () async {
              await Navigator.push(
                context,
                PageTransition(
                  type: PageTransitionType.leftToRight,
                  duration: Duration(milliseconds: 300),
                  reverseDuration: Duration(milliseconds: 300),
                  child: ResultWidget(
                    raceid: widget.raceid,
                    categoria: widget.categoria,
                  ),
                ),
              );
            },
          ),
          flexibleSpace: Align(
            alignment: AlignmentDirectional(0.05, 0.4),
            child: InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomePageWidget(),
                  ),
                );
              },
              child: Text(
                'ordine partenza:',
                style: FlutterFlowTheme.of(context).title2.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 30,
                    ),
              ),
            ),
          ),
          actions: [
            Align(
              alignment: AlignmentDirectional(0, 2),
              child: InkWell(
                onTap: () async {
                  await Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: Duration(milliseconds: 300),
                      reverseDuration: Duration(milliseconds: 300),
                      child: OrganizationResultWidget(
                        raceid: widget.raceid,
                        categoria: widget.categoria,
                      ),
                    ),
                  );
                },
                child: Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 50,
                ),
              ),
            ),
          ],
          elevation: 2,
        ),
      ),
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print('FloatingActionButton pressed ...');
        },
        backgroundColor: Color(0xFFFC6423),
        elevation: 10,
        child: Icon(
          Icons.update,
          color: Colors.white,
          size: 35,
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: FutureBuilder<ApiCallResponse>(
            future: GetstartlistCall.call(
              id: widget.raceid,
              categoria: widget.categoria,
            ),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 50,
                    height: 50,
                    child: CircularProgressIndicator(
                      color: FlutterFlowTheme.of(context).primaryColor,
                    ),
                  ),
                );
              }
              final listViewGetstartlistResponse = snapshot.data;

              return Builder(
                builder: (context) {
                  try{
                  final listaatleti = getJsonField(
                        (listViewGetstartlistResponse?.jsonBody ?? ''),
                        r'''$.griglia_di_partenza[*]''',
                      )?.toList() ??
                      [];
                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: listaatleti.length,
                    itemBuilder: (context, listaatletiIndex) {
                      final listaatletiItem = listaatleti[listaatletiIndex];
                      return Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Color(0xFFFCAA8E),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  getJsonField(
                                    listaatletiItem,
                                    r'''$.nome''',
                                  ).toString(),
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                  
                                ),
                                Text(
                                  'Squadra: ',
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                                Text(
                                  'Partenza ore: ',
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                              ],
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text(
                                  getJsonField(
                                    listaatletiItem,
                                    r'''$.cognome''',
                                  ).toString(),
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                                Text(
                                  getJsonField(
                                    listaatletiItem,
                                    r'''$.organizzazione''',
                                  ).toString(),
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                              
                                ),
                                Text(
                                  getJsonField(
                                    listaatletiItem,
                                    r'''$.tempo''',
                                  ).toString(),
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  );
                } catch (e) {
                  List<String> listaatleti = [];
                  listaatleti.add(getJsonField(
                        (listViewGetstartlistResponse?.jsonBody ?? ''),
                        r'''$.griglia_di_partenza[*]''',
                      )?.toString() ??
                      []);
                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: listaatleti.length,
                    itemBuilder: (context, listaatletiIndex) {
                      final listaatletiItem = listaatleti[listaatletiIndex];
                      listaatleti = listaatleti[0].split(',');
                      return Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Color(0xFFFCAA8E),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  listaatleti[0].split(':')[1],
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                  
                                ),
                                Text(
                                  'Squadra: ',
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                                Text(
                                  'Partenza ore: ',
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                              ],
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text(
                                  listaatleti[1].split(':')[1],
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                                Text(
                                  listaatleti[2].split(':')[1],
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                              
                                ),
                                Text(
                                  listaatleti[3].split(':')[1].split('}')[0],
                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                        fontFamily: 'Poppins',
                                        fontSize: 23,
                                      ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  );
                }
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
