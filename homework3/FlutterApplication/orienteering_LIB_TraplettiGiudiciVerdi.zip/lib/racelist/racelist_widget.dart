import '../backend/api_requests/api_calls.dart';
import '../classlist/classlist_widget.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../home_page/home_page_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RacelistWidget extends StatefulWidget {
  const RacelistWidget({
    Key key,
    this.lista,
  }) : super(key: key);

  final dynamic lista;

  @override
  _RacelistWidgetState createState() => _RacelistWidgetState();
}

class _RacelistWidgetState extends State<RacelistWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
          backgroundColor: Color(0xFFFC6423),
          automaticallyImplyLeading: false,
          leading: Align(
            alignment: AlignmentDirectional(0, 0),
            child: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30,
              borderWidth: 1,
              buttonSize: 80,
              icon: Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 50,
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  PageTransition(
                    type: PageTransitionType.rightToLeft,
                    duration: Duration(milliseconds: 300),
                    reverseDuration: Duration(milliseconds: 300),
                    child: HomePageWidget(),
                  ),
                );
              },
            ),
          ),
          flexibleSpace: Align(
            alignment: AlignmentDirectional(0.1, 0.4),
            child: InkWell(
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomePageWidget(),
                  ),
                );
              },
              child: Text(
                'Lista gare',
                style: FlutterFlowTheme.of(context).title2.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 40,
                    ),
              ),
            ),
          ),
          actions: [],
          elevation: 2,
        ),
      ),
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print('FloatingActionButton pressed ...');
        },
        backgroundColor: Color(0xFFFC6423),
        elevation: 8,
        child: InkWell(
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RacelistWidget(),
              ),
            );
          },
          child: Icon(
            Icons.update,
            color: Colors.white,
            size: 35,
          ),
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: FutureBuilder<ApiCallResponse>(
            future: ListRaceCall.call(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 50,
                    height: 50,
                    child: CircularProgressIndicator(
                      color: FlutterFlowTheme.of(context).primaryColor,
                    ),
                  ),
                );
              }
              final listViewListRaceResponse = snapshot.data;
              return Builder(
                builder: (context) {
                  final listaGare = getJsonField(
                        (listViewListRaceResponse?.jsonBody ?? ''),
                        r'''$.evento[*]''',
                      )?.toList() ??
                      [];
                  return ListView.builder(
                    padding: EdgeInsets.zero,
                    scrollDirection: Axis.vertical,
                    itemCount: listaGare.length,
                    itemBuilder: (context, listaGareIndex) {
                      final listaGareItem = listaGare[listaGareIndex];
                      return Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Color(0xFFFCAA8E),
                        ),
                        child: InkWell(
                          onTap: () async {
                            await Navigator.push(
                              context,
                              PageTransition(
                                type: PageTransitionType.rightToLeft,
                                duration: Duration(milliseconds: 300),
                                reverseDuration: Duration(milliseconds: 300),
                                child: ClasslistWidget(
                                  raceid: getJsonField(
                                    listaGareItem,
                                    r'''$.race_id''',
                                  ).toString(),
                                ),
                              ),
                            );
                          },
                          child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(10, 0, 10, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            
                            children: [
                              Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional(0, 0),
                                    child: Text(
                                      getJsonField(
                                        listaGareItem,
                                        r'''$.race_name''',
                                      ).toString(),
                                      style: FlutterFlowTheme.of(context)
                                          .bodyText1
                                          .override(
                                            fontFamily: 'Poppins',
                                            fontSize: 30,
                                          ),
                                    ),
                                  ),
                                  Text(
                                    getJsonField(
                                      listaGareItem,
                                      r'''$.race_id''',
                                    ).toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText1
                                        .override(
                                          fontFamily: 'Poppins',
                                          fontSize: 25,
                                        ),
                                  ),
                                ],
                              ),
                              Icon(
                                Icons.double_arrow,
                                color: Color(0xFF468D17),
                                size: 60,
                              ),
                            ],
                          ),
                        ),
                      ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
